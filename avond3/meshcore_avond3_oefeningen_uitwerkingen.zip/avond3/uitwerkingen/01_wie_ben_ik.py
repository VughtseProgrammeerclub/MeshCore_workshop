"""
Oefening 1 - Wie ben ik?

Leerdoel: verbinden, async/await, en de eigen node uitlezen.

    python 01_wie_ben_ik.py --serial COM4
"""

import asyncio

from meshcore import EventType
from verbinding import maak_parser, verbind


async def main():
    args = maak_parser("Toon informatie over je eigen node").parse_args()
    mc = await verbind(args)

    try:
        # self_info wordt bij het verbinden al automatisch opgehaald
        info = mc.self_info

        # >>> OPDRACHT 1a: print naam, frequentie, SF, BW en zendvermogen van je node
        print(f"Naam          : {info['name']}")
        print(f"Publieke sleutel: {info['public_key'][:16]}...")
        print(f"Frequentie    : {info['radio_freq']} MHz")
        print(f"Bandbreedte   : {info['radio_bw']} kHz")
        print(f"Spreading factor: SF{info['radio_sf']}")
        print(f"Zendvermogen  : {info['tx_power']} dBm (max {info['max_tx_power']})")
        print(f"Positie       : {info['adv_lat']}, {info['adv_lon']}")
        # <<< OPDRACHT

        # >>> OPDRACHT 1b: vraag de batterijspanning op met mc.commands.get_bat()
        resultaat = await mc.commands.get_bat()
        if resultaat.type == EventType.ERROR:
            print(f"Batterij opvragen mislukt: {resultaat.payload}")
        else:
            mv = resultaat.payload["level"]
            print(f"Batterij      : {mv} mV ({mv / 1000:.2f} V)")
        # <<< OPDRACHT

    finally:
        await mc.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
