"""
Oefening 3 - Een bericht sturen (en weten of het aankwam)

Leerdoel: contact opzoeken, direct message sturen, wachten op een ACK.

    python 03_bericht_sturen.py --serial COM4 --naar "Buurman" --tekst "Hallo vanuit Python!"
"""

import asyncio

from meshcore import EventType
from verbinding import maak_parser, verbind


async def main():
    parser = maak_parser("Stuur een direct message en wacht op de ACK")
    parser.add_argument("--naar", required=True, help="naam van het contact")
    parser.add_argument("--tekst", default="Hallo vanuit Python!", help="het bericht")
    args = parser.parse_args()

    mc = await verbind(args)

    try:
        await mc.ensure_contacts()

        # >>> OPDRACHT 3a: zoek het contact op naam; geef een nette melding als het niet bestaat
        contact = mc.get_contact_by_name(args.naar)
        if contact is None:
            print(f"Contact '{args.naar}' niet gevonden. Bekende namen:")
            for c in mc.contacts.values():
                print(f"  - {c['adv_name']}")
            return
        # <<< OPDRACHT

        # >>> OPDRACHT 3b: verstuur het bericht en wacht op de ACK die erbij hoort
        resultaat = await mc.commands.send_msg(contact, args.tekst)
        if resultaat.type == EventType.ERROR:
            print(f"Versturen mislukt: {resultaat.payload}")
            return

        # De node geeft een 'expected_ack'-code terug: daar filteren we op
        ack_code = resultaat.payload["expected_ack"].hex()
        # en een geschatte wachttijd in milliseconden
        wachttijd = max(resultaat.payload["suggested_timeout"] / 800, 5)
        print(f"Verstuurd, wacht max {wachttijd:.0f} s op ACK {ack_code} ...")

        ack = await mc.wait_for_event(
            EventType.ACK,
            attribute_filters={"code": ack_code},
            timeout=wachttijd,
        )
        if ack:
            print("Afgeleverd!")
        else:
            print("Geen ACK ontvangen (bericht kan alsnog aangekomen zijn).")
        # <<< OPDRACHT

    finally:
        await mc.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
