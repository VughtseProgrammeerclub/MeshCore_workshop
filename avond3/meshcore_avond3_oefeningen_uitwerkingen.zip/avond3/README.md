# MeshCore avond 3 – Programmeren met Python

## Installeren

    python -m venv mesh
    mesh\Scripts\activate          (Windows)   of   source mesh/bin/activate   (Linux/macOS)
    pip install meshcore-cli       (installeert ook de bibliotheek 'meshcore')
    meshcli -l                     (welke poorten/apparaten zie je?)

## Mappen

- `cli/` – meshcli-voorbeelden en een scriptbestand (`meshcli -s COM4 script avond3.txt`)
- `oefeningen/` – scripts met lege OPDRACHT-blokken en hints: vul ze in
- `uitwerkingen/` – complete oplossingen

## Een oefening starten

    cd oefeningen
    python 01_wie_ben_ik.py --serial COM4
    python 01_wie_ben_ik.py --serial /dev/ttyUSB0
    python 01_wie_ben_ik.py --tcp 192.168.1.50:5000

## Spelregels

- Testen in kanaal #avond3, niet in Public.
- Pingbot met je eigen trigger: `--trigger ping-<jouwnaam>`.
- Geen lussen die steeds zenden.
