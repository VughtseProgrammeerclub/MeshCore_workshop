#!/usr/bin/env bash
# meshcli-voorbeelden voor avond 3.
# Vervang PORT door jouw poort (Windows: COM4, Linux: /dev/ttyUSB0).
# Op Windows kun je deze regels gewoon los in PowerShell plakken (zonder PORT=...).

PORT=/dev/ttyUSB0

# --- Verkennen ---------------------------------------------------------
meshcli -l                              # welke apparaten/poorten zie je?
meshcli -s "$PORT" infos                # info over je node
meshcli -s "$PORT" lc                   # contactlijst

# --- Commando's aan elkaar rijgen --------------------------------------
meshcli -s "$PORT" clock sync clock     # klok gelijkzetten en controleren

# --- JSON-uitvoer: handig voor scripts -----------------------------------
meshcli -j -s "$PORT" infos
meshcli -s "$PORT" .lc                  # punt ervoor = alleen dit commando als JSON

# Met jq: alleen de namen van repeaters (type 2)
meshcli -j -s "$PORT" lc | jq -r '.[] | select(.type == 2) | .adv_name'

# Hoeveel contacten heb ik?
meshcli -j -s "$PORT" lc | jq 'length'

# --- Berichten ---------------------------------------------------------
meshcli -s "$PORT" chan 1 "test vanuit de shell"
meshcli -s "$PORT" msg "Buurman" "Hoi!" wait_ack   # direct bericht + wachten op ACK
meshcli -s "$PORT" sync_msgs                        # ongelezen berichten ophalen

# --- Script-bestand ----------------------------------------------------
meshcli -s "$PORT" script avond3.txt

# --- Interactief -------------------------------------------------------
meshcli -s "$PORT"                     # chatmodus; 'to <naam>' kiest een ontvanger, Tab vult aan
