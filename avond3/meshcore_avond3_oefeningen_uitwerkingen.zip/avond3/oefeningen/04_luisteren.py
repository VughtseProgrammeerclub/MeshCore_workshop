"""
Oefening 4 - Luisteren naar het mesh

Leerdoel: event-gedreven programmeren met subscribe() en callbacks.

    python 04_luisteren.py --serial COM4

Stoppen met Ctrl+C.
"""

import asyncio
from datetime import datetime

from meshcore import EventType
from verbinding import maak_parser, verbind


def nu() -> str:
    return datetime.now().strftime("%H:%M:%S")


async def main():
    args = maak_parser("Toon binnenkomende berichten en adverts").parse_args()
    mc = await verbind(args)
    await mc.ensure_contacts()

    # >>> OPDRACHT 4a: callback voor directe berichten; toon de NAAM van de afzender
    async def op_prive_bericht(event):
        # Hint: event.payload['text'] en event.payload['pubkey_prefix']
        # Hint: mc.get_contact_by_key_prefix(prefix) geeft het contact (of None)
        pass  # <- vervang door jouw code
    # <<< OPDRACHT

    # >>> OPDRACHT 4b: callback voor kanaalberichten (tekst is al "Naam: bericht")
    async def op_kanaal_bericht(event):
        # Hint: event.payload['channel_idx'], ['text'] en ['path_len']
        pass  # <- vervang door jouw code
    # <<< OPDRACHT

    async def op_advert(event):
        sleutel = event.payload.get("public_key", "")
        bekend = mc.get_contact_by_key_prefix(sleutel)
        naam = bekend["adv_name"] if bekend else f"onbekend ({sleutel[:12]}...)"
        print(f"[{nu()}] ADVERT  van {naam}")

    mc.subscribe(EventType.CONTACT_MSG_RECV, op_prive_bericht)
    mc.subscribe(EventType.CHANNEL_MSG_RECV, op_kanaal_bericht)
    mc.subscribe(EventType.ADVERTISEMENT, op_advert)

    # Zonder dit haalt de bibliotheek berichten niet zelf op van de node
    await mc.start_auto_message_fetching()

    print("Luisteren... (Ctrl+C om te stoppen)")
    try:
        await asyncio.Event().wait()   # wacht 'voor altijd'
    finally:
        await mc.stop_auto_message_fetching()
        await mc.disconnect()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nGestopt.")
