"""
Oefening 3 - Een bericht sturen (en weten of het aankwam)

Leerdoel: contact opzoeken, direct message sturen, wachten op een ACK.

    python 03_bericht_sturen.py --serial COM4 --naar "Buurman" --tekst "Hallo vanuit Python!"
"""

import asyncio

from meshcore import EventType
from verbinding import maak_parser, verbind


async def main():
    parser = maak_parser("Stuur een direct message en wacht op de ACK")
    parser.add_argument("--naar", required=True, help="naam van het contact")
    parser.add_argument("--tekst", default="Hallo vanuit Python!", help="het bericht")
    args = parser.parse_args()

    mc = await verbind(args)

    try:
        await mc.ensure_contacts()

        # >>> OPDRACHT 3a: zoek het contact op naam; geef een nette melding als het niet bestaat
        # Hint: contact = mc.get_contact_by_name(args.naar)  -> None als hij niet bestaat
        # Hint: alle contacten: mc.contacts.values()
        pass  # <- vervang door jouw code
        # <<< OPDRACHT

        # >>> OPDRACHT 3b: verstuur het bericht en wacht op de ACK die erbij hoort
        # Hint: resultaat = await mc.commands.send_msg(contact, args.tekst)
        # Hint: resultaat.payload['expected_ack'].hex() is de ACK-code
        # Hint: await mc.wait_for_event(EventType.ACK, attribute_filters={'code': ...}, timeout=...)
        pass  # <- vervang door jouw code
        # <<< OPDRACHT

    finally:
        await mc.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
