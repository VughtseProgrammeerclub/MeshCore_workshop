"""
Oefening 1 - Wie ben ik?

Leerdoel: verbinden, async/await, en de eigen node uitlezen.

    python 01_wie_ben_ik.py --serial COM4
"""

import asyncio

from meshcore import EventType
from verbinding import maak_parser, verbind


async def main():
    args = maak_parser("Toon informatie over je eigen node").parse_args()
    mc = await verbind(args)

    try:
        # self_info wordt bij het verbinden al automatisch opgehaald
        info = mc.self_info

        # >>> OPDRACHT 1a: print naam, frequentie, SF, BW en zendvermogen van je node
        # Hint: info is een dict, bv. info['name'], info['radio_freq'], info['radio_sf'],
        # Hint: info['radio_bw'], info['tx_power']
        pass  # <- vervang door jouw code
        # <<< OPDRACHT

        # >>> OPDRACHT 1b: vraag de batterijspanning op met mc.commands.get_bat()
        # Hint: resultaat = await mc.commands.get_bat()
        # Hint: check resultaat.type == EventType.ERROR; anders staat de spanning in
        # Hint: resultaat.payload['level'] (millivolt)
        pass  # <- vervang door jouw code
        # <<< OPDRACHT

    finally:
        await mc.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
