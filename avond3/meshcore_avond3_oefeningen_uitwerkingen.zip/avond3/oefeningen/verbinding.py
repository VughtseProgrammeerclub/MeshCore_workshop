"""
verbinding.py - gedeelde verbindingscode voor alle oefeningen van avond 3.

Elke oefening start zo:

    python 01_wie_ben_ik.py --serial COM4              (Windows)
    python 01_wie_ben_ik.py --serial /dev/ttyUSB0      (Linux)
    python 01_wie_ben_ik.py --tcp 192.168.1.50:5000    (WiFi-companion)
    python 01_wie_ben_ik.py --ble MeshCore-Rudy        (Bluetooth, eerst koppelen!)

Tip: met `meshcli -l` zie je welke poorten/apparaten er zijn.
"""

import argparse
import sys

from meshcore import MeshCore


def maak_parser(beschrijving: str) -> argparse.ArgumentParser:
    """Argument-parser met de drie manieren om te verbinden."""
    parser = argparse.ArgumentParser(description=beschrijving)
    groep = parser.add_mutually_exclusive_group(required=True)
    groep.add_argument("-s", "--serial", metavar="POORT",
                       help="seriele poort, bv. COM4 of /dev/ttyUSB0")
    groep.add_argument("-t", "--tcp", metavar="HOST[:POORT]",
                       help="WiFi-companion, bv. 192.168.1.50:5000")
    groep.add_argument("-a", "--ble", metavar="ADRES",
                       help="Bluetooth-adres of -naam")
    parser.add_argument("--debug", action="store_true",
                        help="laat alle verzonden/ontvangen frames zien")
    return parser


async def verbind(args) -> MeshCore:
    """Maak verbinding met de companion radio. Stopt het script als dat mislukt."""
    if args.serial:
        mc = await MeshCore.create_serial(args.serial, 115200, debug=args.debug)
    elif args.tcp:
        host, _, poort = args.tcp.partition(":")
        mc = await MeshCore.create_tcp(host, int(poort or 5000), debug=args.debug)
    else:
        mc = await MeshCore.create_ble(args.ble, debug=args.debug)

    if mc is None:
        print("Geen antwoord van de node. Controleer:")
        print("  - is de firmware een *companion* (niet repeater/room server)?")
        print("  - serieel? dan moet het ook een USB/serial companion zijn, geen BLE-build")
        print("  - is de poort niet in gebruik door de webapp of meshcli?")
        sys.exit(1)

    naam = mc.self_info.get("name", "?")
    print(f"Verbonden met '{naam}'\n")
    return mc
