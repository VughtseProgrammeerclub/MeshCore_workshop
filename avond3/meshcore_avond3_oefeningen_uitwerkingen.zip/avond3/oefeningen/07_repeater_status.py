"""
Bonus 7 - Status van een repeater opvragen

Leerdoel: inloggen op een repeater en een verzoek-antwoord over het mesh.
Je hebt het (gast)wachtwoord van de repeater nodig.

    python 07_repeater_status.py --serial COM4 --repeater "Vught-RPT" --wachtwoord geheim
"""

import asyncio

from meshcore import EventType
from verbinding import maak_parser, verbind


async def main():
    parser = maak_parser("Vraag de status van een repeater op")
    parser.add_argument("--repeater", required=True, help="naam van de repeater")
    parser.add_argument("--wachtwoord", required=True)
    args = parser.parse_args()

    mc = await verbind(args)

    try:
        await mc.ensure_contacts()
        rep = mc.get_contact_by_name(args.repeater)
        if rep is None:
            print(f"Repeater '{args.repeater}' staat niet in je contacten.")
            return

        print("Inloggen...")
        login = await mc.commands.send_login_sync(rep, args.wachtwoord)
        if login is None or login.type != EventType.LOGIN_SUCCESS:
            print("Inloggen mislukt (verkeerd wachtwoord of geen antwoord).")
            return

        print("Status opvragen...")
        status = await mc.commands.req_status_sync(rep)
        if not status:
            print("Geen antwoord binnen de tijd.")
            return

        velden = {
            "bat": "Batterij (mV)",
            "uptime": "Uptime (s)",
            "nb_recv": "Pakketten ontvangen",
            "nb_sent": "Pakketten verzonden",
            "last_rssi": "Laatste RSSI (dBm)",
            "last_snr": "Laatste SNR (dB)",
            "airtime": "Zendtijd",
            "flood_dups": "Dubbele floods",
        }
        for sleutel, label in velden.items():
            print(f"{label:<22}: {status.get(sleutel, '-')}")

    finally:
        await mc.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
