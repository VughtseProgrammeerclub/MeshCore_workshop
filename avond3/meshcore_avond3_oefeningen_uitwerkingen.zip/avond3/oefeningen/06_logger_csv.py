"""
Bonus 6 - Mesh-logger naar CSV

Leerdoel: data verzamelen voor later (bv. openen in Excel of Grafana).
Logt elk ontvangen radiopakket met signaalsterkte, plus alle berichten.

    python 06_logger_csv.py --serial COM4 --bestand meshlog.csv
"""

import asyncio
import csv
from datetime import datetime

from meshcore import EventType
from verbinding import maak_parser, verbind


async def main():
    parser = maak_parser("Log mesh-verkeer naar een CSV-bestand")
    parser.add_argument("--bestand", default="meshlog.csv")
    args = parser.parse_args()

    mc = await verbind(args)

    f = open(args.bestand, "a", newline="", encoding="utf-8")
    schrijver = csv.writer(f, delimiter=";")
    if f.tell() == 0:
        schrijver.writerow(["tijd", "soort", "rssi", "snr", "kanaal", "tekst"])

    def log(*kolommen):
        schrijver.writerow([datetime.now().isoformat(timespec="seconds"), *kolommen])
        f.flush()   # direct wegschrijven, ook als het script crasht

    # Elk pakket dat de radio hoort, ook als het niet voor ons is
    async def op_rf_pakket(event):
        p = event.payload
        log("rf", p.get("rssi"), p.get("snr"), "", "")
        print(f"rf   RSSI {p.get('rssi')} dBm  SNR {p.get('snr')} dB")

    async def op_kanaal_bericht(event):
        m = event.payload
        log("kanaal", "", "", m["channel_idx"], m["text"])
        print(f"msg  [{m['channel_idx']}] {m['text']}")

    async def op_prive_bericht(event):
        m = event.payload
        log("prive", "", "", "", m["text"])
        print(f"prv  {m['text']}")

    mc.subscribe(EventType.RX_LOG_DATA, op_rf_pakket)
    mc.subscribe(EventType.CHANNEL_MSG_RECV, op_kanaal_bericht)
    mc.subscribe(EventType.CONTACT_MSG_RECV, op_prive_bericht)
    await mc.start_auto_message_fetching()

    print(f"Loggen naar {args.bestand} ... (Ctrl+C om te stoppen)")
    try:
        await asyncio.Event().wait()
    finally:
        await mc.stop_auto_message_fetching()
        await mc.disconnect()
        f.close()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nGestopt.")
