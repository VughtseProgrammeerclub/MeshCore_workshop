"""
Oefening 2 - Wie hoor ik?

Leerdoel: de contactlijst ophalen en er een nette tabel van maken.

    python 02_contacten.py --serial COM4
"""

import asyncio
import time

from meshcore import EventType
from verbinding import maak_parser, verbind

# Het 'type' van een contact is een getal; dit maakt het leesbaar
TYPES = {1: "chat", 2: "repeater", 3: "room", 4: "sensor"}


def hoe_lang_geleden(timestamp: int) -> str:
    sec = int(time.time()) - timestamp
    if sec < 0:
        return "klok?"       # klok van de andere node loopt voor
    if sec < 3600:
        return f"{sec // 60} min"
    if sec < 86400:
        return f"{sec // 3600} uur"
    return f"{sec // 86400} dag"


async def main():
    args = maak_parser("Toon de contactlijst van je node").parse_args()
    mc = await verbind(args)

    try:
        resultaat = await mc.commands.get_contacts()
        if resultaat.type == EventType.ERROR:
            print(f"Fout: {resultaat.payload}")
            return

        # payload is een dict: {publieke_sleutel: contact_dict}
        contacten = list(resultaat.payload.values())

        # >>> OPDRACHT 2a: sorteer de contacten op 'last_advert', nieuwste eerst
        # Hint: lijst.sort(key=lambda c: ..., reverse=True)
        pass  # <- vervang door jouw code
        # <<< OPDRACHT

        print(f"{'Naam':<24} {'Type':<9} {'Hops':>4}  Laatst gezien")
        print("-" * 56)
        for c in contacten:
            # >>> OPDRACHT 2b: print per contact naam, type (leesbaar), hops en 'laatst gezien'
            # Hint: velden: c['adv_name'], c['type'], c['out_path_len'] (-1 = flood), c['last_advert']
            # Hint: gebruik TYPES en hoe_lang_geleden()
            pass  # <- vervang door jouw code
            # <<< OPDRACHT

        # >>> OPDRACHT 2c (extra): tel hoeveel contacten er per type zijn
        print()
        for nr, soort in TYPES.items():
            aantal = sum(1 for c in contacten if c["type"] == nr)
            print(f"{soort:<9}: {aantal}")
        # <<< OPDRACHT

    finally:
        await mc.disconnect()


if __name__ == "__main__":
    asyncio.run(main())
