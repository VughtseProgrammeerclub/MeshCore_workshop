"""
Oefening 5 - Je eerste bot

Leerdoel: luisteren EN reageren. De bot antwoordt in een workshopkanaal op
een trigger-woord.

LET OP: we gebruiken een eigen hashtag-kanaal, niet het Public-kanaal.
Zo vullen we het echte mesh niet met twintig testbots.

    python 05_pingbot.py --serial COM4 --trigger ping-rudy

Iedere deelnemer kiest een eigen trigger (bv. ping-<jouwnaam>), zodat niet
alle bots tegelijk antwoorden.
"""

import asyncio

from meshcore import EventType
from verbinding import maak_parser, verbind

KANAAL_IDX = 1               # kanaalslot op je node (0 = Public, laat die met rust)
KANAAL_NAAM = "#avond3"      # hashtag-kanaal: sleutel wordt afgeleid van de naam


async def main():
    parser = maak_parser("Een simpele ping-bot")
    parser.add_argument("--trigger", default="ping", help="woord waarop de bot reageert")
    args = parser.parse_args()

    mc = await verbind(args)

    # Zet het workshopkanaal in slot 1. Bij een '#'-naam rekent de bibliotheek
    # de sleutel zelf uit, dus iedereen met dezelfde naam zit in hetzelfde kanaal.
    resultaat = await mc.commands.set_channel(KANAAL_IDX, KANAAL_NAAM)
    if resultaat.type == EventType.ERROR:
        print(f"Kanaal instellen mislukt: {resultaat.payload}")
        await mc.disconnect()
        return
    print(f"Kanaal {KANAAL_NAAM} staat in slot {KANAAL_IDX}")

    trigger = args.trigger.lower()

    # >>> OPDRACHT 5a: reageer met 'pong' als het trigger-woord in een bericht staat
    async def op_kanaal_bericht(event):
        # Hint: msg['text'] heeft de vorm 'Afzender: bericht' -> tekst.partition(': ')
        # Hint: antwoorden: await mc.commands.send_chan_msg(KANAAL_IDX, antwoord)
        pass  # <- vervang door jouw code
    # <<< OPDRACHT

    # Alleen berichten uit ons eigen kanaal doorlaten
    mc.subscribe(
        EventType.CHANNEL_MSG_RECV,
        op_kanaal_bericht,
        attribute_filters={"channel_idx": KANAAL_IDX},
    )
    await mc.start_auto_message_fetching()

    print(f"Bot actief: stuur '{args.trigger}' in {KANAAL_NAAM}. Ctrl+C om te stoppen.")
    try:
        await asyncio.Event().wait()
    finally:
        await mc.stop_auto_message_fetching()
        await mc.disconnect()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nBot gestopt.")
